{
  "id": "7a5e5797-038b-4e18-8e1a-571822b241d4",
  "version": "2.0",
  "name": "ПР11",
  "url": "https://opensource-demo.orangehrmlive.com/index.php/leave/viewLeaveList/reset/1",
  "tests": [{
    "id": "2b73609c-7020-4e9c-88f0-6184309deca0",
    "name": "Untitled",
    "commands": [{
      "id": "b3bd5205-eb3a-40fb-9744-3a5e5f186848",
      "comment": "",
      "command": "open",
      "target": "/",
      "targets": [],
      "value": ""
    }, {
      "id": "e25dcdd4-4cea-4aed-8120-cda6a7f1a4e0",
      "comment": "",
      "command": "setWindowSize",
      "target": "857x1040",
      "targets": [],
      "value": ""
    }, {
      "id": "39cee0dc-ea7d-4c7d-9413-e61d0bba8dc6",
      "comment": "",
      "command": "click",
      "target": "css=#divUsername > .form-hint",
      "targets": [
        ["css=#divUsername > .form-hint", "css:finder"],
        ["xpath=//div[@id='divUsername']/span", "xpath:idRelative"],
        ["xpath=//form/div[2]/span", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "18d954bc-80f1-40dd-a507-e9926f5d9eba",
      "comment": "",
      "command": "click",
      "target": "css=span:nth-child(1)",
      "targets": [
        ["css=span:nth-child(1)", "css:finder"],
        ["xpath=//div[@id='content']/div[2]/span", "xpath:idRelative"],
        ["xpath=//span", "xpath:position"],
        ["xpath=//span[contains(.,'( Username : Admin | Password : admin123 )')]", "xpath:innerText"]
      ],
      "value": ""
    }, {
      "id": "9bf653e8-7b00-47dc-9857-bf19d31a9ad8",
      "comment": "",
      "command": "click",
      "target": "id=txtUsername",
      "targets": [
        ["id=txtUsername", "id"],
        ["name=txtUsername", "name"],
        ["css=#txtUsername", "css:finder"],
        ["xpath=//input[@id='txtUsername']", "xpath:attributes"],
        ["xpath=//div[@id='divUsername']/input", "xpath:idRelative"],
        ["xpath=//div[2]/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "4efca12e-a143-4edc-bb9e-4e2565de20d6",
      "comment": "",
      "command": "type",
      "target": "id=txtUsername",
      "targets": [
        ["id=txtUsername", "id"],
        ["name=txtUsername", "name"],
        ["css=#txtUsername", "css:finder"],
        ["xpath=//input[@id='txtUsername']", "xpath:attributes"],
        ["xpath=//div[@id='divUsername']/input", "xpath:idRelative"],
        ["xpath=//div[2]/input", "xpath:position"]
      ],
      "value": "Admin"
    }, {
      "id": "ad890fd6-a9eb-4caa-ba52-85c250a4cf52",
      "comment": "",
      "command": "click",
      "target": "id=txtPassword",
      "targets": [
        ["id=txtPassword", "id"],
        ["name=txtPassword", "name"],
        ["css=#txtPassword", "css:finder"],
        ["xpath=//input[@id='txtPassword']", "xpath:attributes"],
        ["xpath=//div[@id='divPassword']/input", "xpath:idRelative"],
        ["xpath=//div[3]/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "29a46077-620b-4089-9527-173d8537971f",
      "comment": "",
      "command": "close",
      "target": "",
      "targets": [],
      "value": ""
    }]
  }, {
    "id": "df17e8bf-e8e7-4ea1-92af-cae71f156a49",
    "name": "ВХОД",
    "commands": [{
      "id": "4a839794-5fc3-4298-a3ab-7bde07eb12c5",
      "comment": "",
      "command": "open",
      "target": "https://opensource-demo.orangehrmlive.com/",
      "targets": [],
      "value": ""
    }, {
      "id": "f5369d83-c432-4dbe-9f70-3683a5c2a433",
      "comment": "",
      "command": "setWindowSize",
      "target": "857x1040",
      "targets": [],
      "value": ""
    }, {
      "id": "6515aad0-d0af-4495-8a0b-6b66d1c4e7fa",
      "comment": "",
      "command": "click",
      "target": "css=#divUsername > .form-hint",
      "targets": [
        ["css=#divUsername > .form-hint", "css:finder"],
        ["xpath=//div[@id='divUsername']/span", "xpath:idRelative"],
        ["xpath=//form/div[2]/span", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "05a2ea06-a435-4c37-baf9-2e2550f6bd04",
      "comment": "",
      "command": "type",
      "target": "id=txtUsername",
      "targets": [
        ["id=txtUsername", "id"],
        ["name=txtUsername", "name"],
        ["css=#txtUsername", "css:finder"],
        ["xpath=//input[@id='txtUsername']", "xpath:attributes"],
        ["xpath=//div[@id='divUsername']/input", "xpath:idRelative"],
        ["xpath=//div[2]/input", "xpath:position"]
      ],
      "value": "Admin"
    }, {
      "id": "0e0b2ba1-deb2-4861-b6c5-6865beb6d962",
      "comment": "",
      "command": "click",
      "target": "id=txtPassword",
      "targets": [
        ["id=txtPassword", "id"],
        ["name=txtPassword", "name"],
        ["css=#txtPassword", "css:finder"],
        ["xpath=//input[@id='txtPassword']", "xpath:attributes"],
        ["xpath=//div[@id='divPassword']/input", "xpath:idRelative"],
        ["xpath=//div[3]/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "5ac3c824-caed-491c-9479-dfdae5a28ad6",
      "comment": "",
      "command": "type",
      "target": "id=txtPassword",
      "targets": [
        ["id=txtPassword", "id"],
        ["name=txtPassword", "name"],
        ["css=#txtPassword", "css:finder"],
        ["xpath=//input[@id='txtPassword']", "xpath:attributes"],
        ["xpath=//div[@id='divPassword']/input", "xpath:idRelative"],
        ["xpath=//div[3]/input", "xpath:position"]
      ],
      "value": "admin123"
    }, {
      "id": "6f46926c-1482-43b3-a513-dc3237680fb9",
      "comment": "",
      "command": "click",
      "target": "id=btnLogin",
      "targets": [
        ["id=btnLogin", "id"],
        ["name=Submit", "name"],
        ["css=#btnLogin", "css:finder"],
        ["xpath=//input[@id='btnLogin']", "xpath:attributes"],
        ["xpath=//div[@id='divLoginButton']/input", "xpath:idRelative"],
        ["xpath=//div[5]/input", "xpath:position"]
      ],
      "value": ""
    }]
  }, {
    "id": "0d0acc0f-8382-4766-8fff-9b5be46123b8",
    "name": "02",
    "commands": [{
      "id": "018548cf-68c9-4840-9183-01081dcd7ff0",
      "comment": "",
      "command": "open",
      "target": "https://opensource-demo.orangehrmlive.com/index.php/dashboard",
      "targets": [],
      "value": ""
    }, {
      "id": "9d7bf8e3-7562-4b21-8fda-0758e42cd4a9",
      "comment": "",
      "command": "setWindowSize",
      "target": "1088x1040",
      "targets": [],
      "value": ""
    }, {
      "id": "5b89ea95-083e-47a8-abe7-ee82db0e8320",
      "comment": "",
      "command": "click",
      "target": "css=td:nth-child(1) img",
      "targets": [
        ["css=td:nth-child(1) img", "css:finder"],
        ["xpath=//div[@id='dashboard-quick-launch-panel-menu_holder']/table/tbody/tr/td/div/a/img", "xpath:idRelative"],
        ["xpath=//td/div/a/img", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "77191833-d6e9-4fe7-8452-0ce18881b426",
      "comment": "",
      "command": "click",
      "target": "css=#menu_pim_viewMyDetails > b",
      "targets": [
        ["css=#menu_pim_viewMyDetails > b", "css:finder"],
        ["xpath=//a[@id='menu_pim_viewMyDetails']/b", "xpath:idRelative"],
        ["xpath=//li[6]/a/b", "xpath:position"],
        ["xpath=//b[contains(.,'My Info')]", "xpath:innerText"]
      ],
      "value": ""
    }, {
      "id": "8adda7c2-fa33-4055-a3ca-73a8c4490a07",
      "comment": "",
      "command": "click",
      "target": "id=empPic",
      "targets": [
        ["id=empPic", "id"],
        ["css=#empPic", "css:finder"],
        ["xpath=//img[@alt='Employee Photo']", "xpath:img"],
        ["xpath=//img[@id='empPic']", "xpath:attributes"],
        ["xpath=//div[@id='profile-pic']/div/a/img", "xpath:idRelative"],
        ["xpath=//div/div/div/a/img", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "ed0e9b8f-1df1-410a-8da1-70a2e8dfa294",
      "comment": "",
      "command": "click",
      "target": "id=photofile",
      "targets": [
        ["id=photofile", "id"],
        ["name=photofile", "name"],
        ["css=#photofile", "css:finder"],
        ["xpath=//input[@id='photofile']", "xpath:attributes"],
        ["xpath=//form[@id='frmPhoto']/fieldset/ol/li/input", "xpath:idRelative"],
        ["xpath=//li/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "ec5a2e58-5e2b-4823-8fe0-d8652ea44c6d",
      "comment": "",
      "command": "type",
      "target": "id=photofile",
      "targets": [
        ["id=photofile", "id"],
        ["name=photofile", "name"],
        ["css=#photofile", "css:finder"],
        ["xpath=//input[@id='photofile']", "xpath:attributes"],
        ["xpath=//form[@id='frmPhoto']/fieldset/ol/li/input", "xpath:idRelative"],
        ["xpath=//li/input", "xpath:position"]
      ],
      "value": "C:\\fakepath\\5bbbfe289f0d3-thumbnail.jpg"
    }, {
      "id": "6f653c10-52e2-43ec-bcb3-f54cfaba68a8",
      "comment": "",
      "command": "click",
      "target": "id=btnSave",
      "targets": [
        ["id=btnSave", "id"],
        ["css=#btnSave", "css:finder"],
        ["xpath=//input[@id='btnSave']", "xpath:attributes"],
        ["xpath=//form[@id='frmPhoto']/fieldset/p/input", "xpath:idRelative"],
        ["xpath=//p/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "2e329722-3720-4a51-8f6e-7f8dc66417e2",
      "comment": "",
      "command": "close",
      "target": "",
      "targets": [],
      "value": ""
    }]
  }, {
    "id": "69cbad02-03a7-4003-81ad-a5459b22643b",
    "name": "03",
    "commands": [{
      "id": "5ee625d6-de8d-41c2-9ebe-867f0b4fe2fe",
      "comment": "",
      "command": "open",
      "target": "https://opensource-demo.orangehrmlive.com/index.php/dashboard",
      "targets": [],
      "value": ""
    }, {
      "id": "24df5bb0-7c7b-4e50-8072-5b411f298b87",
      "comment": "",
      "command": "setWindowSize",
      "target": "857x1040",
      "targets": [],
      "value": ""
    }, {
      "id": "9c959a6b-9e99-4b5f-a925-c5ffe10d0efc",
      "comment": "",
      "command": "click",
      "target": "css=#menu_pim_viewMyDetails > b",
      "targets": [
        ["css=#menu_pim_viewMyDetails > b", "css:finder"],
        ["xpath=//a[@id='menu_pim_viewMyDetails']/b", "xpath:idRelative"],
        ["xpath=//li[6]/a/b", "xpath:position"],
        ["xpath=//b[contains(.,'My Info')]", "xpath:innerText"]
      ],
      "value": ""
    }, {
      "id": "1f20a58a-a697-452d-bb7b-eed729c60de4",
      "comment": "",
      "command": "click",
      "target": "id=personal_txtEmpFirstName",
      "targets": [
        ["id=personal_txtEmpFirstName", "id"],
        ["name=personal[txtEmpFirstName]", "name"],
        ["css=#personal_txtEmpFirstName", "css:finder"],
        ["xpath=//input[@id='personal_txtEmpFirstName']", "xpath:attributes"],
        ["xpath=//form[@id='frmEmpPersonalDetails']/fieldset/ol/li/ol/li/input", "xpath:idRelative"],
        ["xpath=//li/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "d56d0715-00bc-4d91-b540-81c89579855d",
      "comment": "",
      "command": "click",
      "target": "id=personal_txtEmpFirstName",
      "targets": [
        ["id=personal_txtEmpFirstName", "id"],
        ["name=personal[txtEmpFirstName]", "name"],
        ["css=#personal_txtEmpFirstName", "css:finder"],
        ["xpath=//input[@id='personal_txtEmpFirstName']", "xpath:attributes"],
        ["xpath=//form[@id='frmEmpPersonalDetails']/fieldset/ol/li/ol/li/input", "xpath:idRelative"],
        ["xpath=//li/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "17753eaa-7dd4-4d03-8c76-5a4aff357f8e",
      "comment": "",
      "command": "click",
      "target": "id=personal_txtEmpFirstName",
      "targets": [
        ["id=personal_txtEmpFirstName", "id"],
        ["name=personal[txtEmpFirstName]", "name"],
        ["css=#personal_txtEmpFirstName", "css:finder"],
        ["xpath=//input[@id='personal_txtEmpFirstName']", "xpath:attributes"],
        ["xpath=//form[@id='frmEmpPersonalDetails']/fieldset/ol/li/ol/li/input", "xpath:idRelative"],
        ["xpath=//li/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "b4dda835-acc4-4ad7-b85c-bc83095d4261",
      "comment": "",
      "command": "click",
      "target": "id=personal_txtEmpFirstName",
      "targets": [
        ["id=personal_txtEmpFirstName", "id"],
        ["name=personal[txtEmpFirstName]", "name"],
        ["css=#personal_txtEmpFirstName", "css:finder"],
        ["xpath=//input[@id='personal_txtEmpFirstName']", "xpath:attributes"],
        ["xpath=//form[@id='frmEmpPersonalDetails']/fieldset/ol/li/ol/li/input", "xpath:idRelative"],
        ["xpath=//li/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "e82333a7-35bb-4e17-a44b-cd30f5d127e1",
      "comment": "",
      "command": "click",
      "target": "id=personal_txtEmpLastName",
      "targets": [
        ["id=personal_txtEmpLastName", "id"],
        ["name=personal[txtEmpLastName]", "name"],
        ["css=#personal_txtEmpLastName", "css:finder"],
        ["xpath=//input[@id='personal_txtEmpLastName']", "xpath:attributes"],
        ["xpath=//form[@id='frmEmpPersonalDetails']/fieldset/ol/li/ol/li[3]/input", "xpath:idRelative"],
        ["xpath=//li[3]/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "841b1c1e-b6f5-47a0-8fcf-6babc35d6b75",
      "comment": "",
      "command": "click",
      "target": "id=personal_txtEmpMiddleName",
      "targets": [
        ["id=personal_txtEmpMiddleName", "id"],
        ["name=personal[txtEmpMiddleName]", "name"],
        ["css=#personal_txtEmpMiddleName", "css:finder"],
        ["xpath=//input[@id='personal_txtEmpMiddleName']", "xpath:attributes"],
        ["xpath=//form[@id='frmEmpPersonalDetails']/fieldset/ol/li/ol/li[2]/input", "xpath:idRelative"],
        ["xpath=//li[2]/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "d8ac6659-7eb6-4d23-9b07-5bd9b657da73",
      "comment": "",
      "command": "click",
      "target": "id=btnSave",
      "targets": [
        ["id=btnSave", "id"],
        ["css=#btnSave", "css:finder"],
        ["xpath=//input[@id='btnSave']", "xpath:attributes"],
        ["xpath=//form[@id='frmEmpPersonalDetails']/fieldset/p/input", "xpath:idRelative"],
        ["xpath=//p/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "011f9286-67b1-41dc-aa73-c95c4510403d",
      "comment": "",
      "command": "click",
      "target": "id=personal_txtEmpMiddleName",
      "targets": [
        ["id=personal_txtEmpMiddleName", "id"],
        ["name=personal[txtEmpMiddleName]", "name"],
        ["css=#personal_txtEmpMiddleName", "css:finder"],
        ["xpath=//input[@id='personal_txtEmpMiddleName']", "xpath:attributes"],
        ["xpath=//form[@id='frmEmpPersonalDetails']/fieldset/ol/li/ol/li[2]/input", "xpath:idRelative"],
        ["xpath=//li[2]/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "9a2dd1fb-1ca0-4604-ac90-1086aabcdfe8",
      "comment": "",
      "command": "click",
      "target": "id=personal_txtEmpFirstName",
      "targets": [
        ["id=personal_txtEmpFirstName", "id"],
        ["name=personal[txtEmpFirstName]", "name"],
        ["css=#personal_txtEmpFirstName", "css:finder"],
        ["xpath=//input[@id='personal_txtEmpFirstName']", "xpath:attributes"],
        ["xpath=//form[@id='frmEmpPersonalDetails']/fieldset/ol/li/ol/li/input", "xpath:idRelative"],
        ["xpath=//li/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "01f17271-d147-4d1e-96c8-bbf0de5f17ff",
      "comment": "",
      "command": "type",
      "target": "id=personal_txtEmpFirstName",
      "targets": [
        ["id=personal_txtEmpFirstName", "id"],
        ["name=personal[txtEmpFirstName]", "name"],
        ["css=#personal_txtEmpFirstName", "css:finder"],
        ["xpath=//input[@id='personal_txtEmpFirstName']", "xpath:attributes"],
        ["xpath=//form[@id='frmEmpPersonalDetails']/fieldset/ol/li/ol/li/input", "xpath:idRelative"],
        ["xpath=//li/input", "xpath:position"]
      ],
      "value": "faul"
    }, {
      "id": "5422502e-8e76-4fc5-8aa4-bb79513fad25",
      "comment": "",
      "command": "click",
      "target": "id=btnSave",
      "targets": [
        ["id=btnSave", "id"],
        ["css=#btnSave", "css:finder"],
        ["xpath=//input[@id='btnSave']", "xpath:attributes"],
        ["xpath=//form[@id='frmEmpPersonalDetails']/fieldset/p/input", "xpath:idRelative"],
        ["xpath=//p/input", "xpath:position"]
      ],
      "value": ""
    }]
  }, {
    "id": "8f640f9c-251e-40f9-ac6e-22bc61ee4650",
    "name": "04",
    "commands": [{
      "id": "daa54553-4c9e-4960-8c28-61a37a52b530",
      "comment": "",
      "command": "open",
      "target": "https://opensource-demo.orangehrmlive.com/index.php/recruitment/viewJobVacancy",
      "targets": [],
      "value": ""
    }, {
      "id": "326ed463-71e3-4e13-8df4-9ce4c64abd11",
      "comment": "",
      "command": "setWindowSize",
      "target": "857x1040",
      "targets": [],
      "value": ""
    }, {
      "id": "5415c58d-c95e-4a75-b8f6-f74bcc0bacd5",
      "comment": "",
      "command": "click",
      "target": "css=ol > li:nth-child(1)",
      "targets": [
        ["css=ol > li:nth-child(1)", "css:finder"],
        ["xpath=//form[@id='frmSrchJobVacancy']/fieldset/ol/li", "xpath:idRelative"],
        ["xpath=//ol/li", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "59cf1ac6-ce0d-47f3-85ba-bee6c8757826",
      "comment": "",
      "command": "click",
      "target": "id=vacancySearch_jobTitle",
      "targets": [
        ["id=vacancySearch_jobTitle", "id"],
        ["name=vacancySearch[jobTitle]", "name"],
        ["css=#vacancySearch_jobTitle", "css:finder"],
        ["xpath=//select[@id='vacancySearch_jobTitle']", "xpath:attributes"],
        ["xpath=//form[@id='frmSrchJobVacancy']/fieldset/ol/li/select", "xpath:idRelative"],
        ["xpath=//select", "xpath:position"],
        ["xpath=//select[contains(.,'All\nAccount Assistant\nAnalyst\nanalyst\nChief Executive Officer\nChief Financial Officer\nChief Technical Officer\nconsult\nContent Specialist\nCustomer Success Manager\nDatabase Administrator\nEngineer\nFinance Manager\nFinancial Analyst\nHead of Support\nHR Associate\nHR Manager\nIT Manager\nNetwork Administrator\nPayroll Administrator\nPre-Sales Coordinator\nQA Engineer\nQA Lead\nSales Representative\nSenior Analyst\nSenior consultant\nSenior Engineer\nSenior Manager\nSocial Media Marketer\nSoftware Architect\nSoftware Engineer\nSupport Specialist\nTest Analyst\ntest engineer\nVP - Client Services\nVP - Sales & Marketing')]", "xpath:innerText"]
      ],
      "value": ""
    }, {
      "id": "cc28eadc-2985-42fe-bd7c-ce78895f715f",
      "comment": "",
      "command": "select",
      "target": "id=vacancySearch_jobTitle",
      "targets": [],
      "value": "label=Account Assistant"
    }, {
      "id": "6c4cea8c-7412-4743-8258-b7d70da92478",
      "comment": "",
      "command": "click",
      "target": "id=vacancySearch_jobTitle",
      "targets": [
        ["id=vacancySearch_jobTitle", "id"],
        ["name=vacancySearch[jobTitle]", "name"],
        ["css=#vacancySearch_jobTitle", "css:finder"],
        ["xpath=//select[@id='vacancySearch_jobTitle']", "xpath:attributes"],
        ["xpath=//form[@id='frmSrchJobVacancy']/fieldset/ol/li/select", "xpath:idRelative"],
        ["xpath=//select", "xpath:position"],
        ["xpath=//select[contains(.,'All\nAccount Assistant\nAnalyst\nanalyst\nChief Executive Officer\nChief Financial Officer\nChief Technical Officer\nconsult\nContent Specialist\nCustomer Success Manager\nDatabase Administrator\nEngineer\nFinance Manager\nFinancial Analyst\nHead of Support\nHR Associate\nHR Manager\nIT Manager\nNetwork Administrator\nPayroll Administrator\nPre-Sales Coordinator\nQA Engineer\nQA Lead\nSales Representative\nSenior Analyst\nSenior consultant\nSenior Engineer\nSenior Manager\nSocial Media Marketer\nSoftware Architect\nSoftware Engineer\nSupport Specialist\nTest Analyst\ntest engineer\nVP - Client Services\nVP - Sales & Marketing')]", "xpath:innerText"]
      ],
      "value": ""
    }, {
      "id": "7ced66b8-19d4-4e77-9960-13d397562ecc",
      "comment": "",
      "command": "click",
      "target": "id=btnSrch",
      "targets": [
        ["id=btnSrch", "id"],
        ["name=btnSrch", "name"],
        ["css=#btnSrch", "css:finder"],
        ["xpath=//input[@id='btnSrch']", "xpath:attributes"],
        ["xpath=//form[@id='frmSrchJobVacancy']/fieldset/p/input", "xpath:idRelative"],
        ["xpath=//p/input", "xpath:position"]
      ],
      "value": ""
    }]
  }, {
    "id": "7718ceb8-1a64-49c3-8b95-3c070483be20",
    "name": "05",
    "commands": [{
      "id": "00a819a0-e64b-4591-81a6-404d05befc5f",
      "comment": "",
      "command": "open",
      "target": "https://opensource-demo.orangehrmlive.com/",
      "targets": [],
      "value": ""
    }, {
      "id": "0a80d83a-2fd8-4f9c-932b-8ae4ebe53d5b",
      "comment": "",
      "command": "setWindowSize",
      "target": "857x1040",
      "targets": [],
      "value": ""
    }, {
      "id": "7c996f64-d922-44a1-a2d2-d1c515a06a6a",
      "comment": "",
      "command": "click",
      "target": "css=#divUsername > .form-hint",
      "targets": [
        ["css=#divUsername > .form-hint", "css:finder"],
        ["xpath=//div[@id='divUsername']/span", "xpath:idRelative"],
        ["xpath=//form/div[2]/span", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "ad8ae131-7a21-4672-a421-db16dbf396d4",
      "comment": "",
      "command": "type",
      "target": "id=txtUsername",
      "targets": [
        ["id=txtUsername", "id"],
        ["name=txtUsername", "name"],
        ["css=#txtUsername", "css:finder"],
        ["xpath=//input[@id='txtUsername']", "xpath:attributes"],
        ["xpath=//div[@id='divUsername']/input", "xpath:idRelative"],
        ["xpath=//div[2]/input", "xpath:position"]
      ],
      "value": "hddgjjfdjd"
    }, {
      "id": "51d5f223-7e42-4ce8-b00d-34fe02ec3b47",
      "comment": "",
      "command": "click",
      "target": "id=txtPassword",
      "targets": [
        ["id=txtPassword", "id"],
        ["name=txtPassword", "name"],
        ["css=#txtPassword", "css:finder"],
        ["xpath=//input[@id='txtPassword']", "xpath:attributes"],
        ["xpath=//div[@id='divPassword']/input", "xpath:idRelative"],
        ["xpath=//div[3]/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "dcea4ba7-9c5e-4c8b-b316-ccc512c32bb1",
      "comment": "",
      "command": "type",
      "target": "id=txtPassword",
      "targets": [
        ["id=txtPassword", "id"],
        ["name=txtPassword", "name"],
        ["css=#txtPassword", "css:finder"],
        ["xpath=//input[@id='txtPassword']", "xpath:attributes"],
        ["xpath=//div[@id='divPassword']/input", "xpath:idRelative"],
        ["xpath=//div[3]/input", "xpath:position"]
      ],
      "value": "admin123"
    }, {
      "id": "6ce6c175-13cd-42dd-8597-3b19f131d1f7",
      "comment": "",
      "command": "click",
      "target": "id=btnLogin",
      "targets": [
        ["id=btnLogin", "id"],
        ["name=Submit", "name"],
        ["css=#btnLogin", "css:finder"],
        ["xpath=//input[@id='btnLogin']", "xpath:attributes"],
        ["xpath=//div[@id='divLoginButton']/input", "xpath:idRelative"],
        ["xpath=//div[5]/input", "xpath:position"]
      ],
      "value": ""
    }]
  }, {
    "id": "a62be479-bfe5-41f8-937a-e552c166cfe9",
    "name": "06",
    "commands": [{
      "id": "29eea6b8-bea6-411d-a7d0-e4dfe11f18ab",
      "comment": "",
      "command": "open",
      "target": "https://opensource-demo.orangehrmlive.com/index.php/dashboard",
      "targets": [],
      "value": ""
    }, {
      "id": "955a6345-99d3-4111-a0ca-4a2ce244616b",
      "comment": "",
      "command": "setWindowSize",
      "target": "940x1040",
      "targets": [],
      "value": ""
    }, {
      "id": "0f4f9056-9052-46f5-a13a-bf55d30cd173",
      "comment": "",
      "command": "click",
      "target": "id=welcome",
      "targets": [
        ["id=welcome", "id"],
        ["linkText=Добро пожаловать, фол", "linkText"],
        ["css=#welcome", "css:finder"],
        ["xpath=//a[@id='welcome']", "xpath:attributes"],
        ["xpath=//div[@id='branding']/a[2]", "xpath:idRelative"],
        ["xpath=//a[contains(@href, '#')]", "xpath:href"],
        ["xpath=//a[2]", "xpath:position"],
        ["xpath=//a[contains(.,'Добро пожаловать, фол')]", "xpath:innerText"]
      ],
      "value": ""
    }, {
      "id": "eeaeb490-cab7-44d8-a171-0dee83021b2c",
      "comment": "",
      "command": "click",
      "target": "css=ul:nth-child(1) > li:nth-child(2) > a > font > font",
      "targets": [
        ["css=ul:nth-child(1) > li:nth-child(2) > a > font > font", "css:finder"],
        ["xpath=//div[@id='welcome-menu']/ul/li[2]/a/font/font", "xpath:idRelative"],
        ["xpath=//li[2]/a/font/font", "xpath:position"]
      ],
      "value": ""
    }]
  }, {
    "id": "bfd6aa30-1bf5-4dca-9dda-eb6a1b5d0f0e",
    "name": "07",
    "commands": [{
      "id": "7e6a0c2e-131a-4667-8072-31395fee2991",
      "comment": "",
      "command": "open",
      "target": "https://opensource-demo.orangehrmlive.com/index.php/leave/viewLeaveList/reset/1",
      "targets": [],
      "value": ""
    }, {
      "id": "36da1bbc-25bc-4a32-9236-d95b61b56190",
      "comment": "",
      "command": "setWindowSize",
      "target": "940x1040",
      "targets": [],
      "value": ""
    }, {
      "id": "c463675e-182c-4401-97a2-6e0eb2f776e7",
      "comment": "",
      "command": "click",
      "target": "id=select_leave_action_28",
      "targets": [
        ["id=select_leave_action_28", "id"],
        ["name=select_leave_action_28", "name"],
        ["css=#select_leave_action_28", "css:finder"],
        ["xpath=//select[@id='select_leave_action_28']", "xpath:attributes"],
        ["xpath=//table[@id='resultTable']/tbody/tr/td[8]/select", "xpath:idRelative"],
        ["xpath=//td[8]/select", "xpath:position"],
        ["xpath=//select[contains(.,'Select Action\nApprove\nCancel\nReject')]", "xpath:innerText"]
      ],
      "value": ""
    }, {
      "id": "7cdd8e06-ebc5-4386-b7ca-332264cd7e65",
      "comment": "",
      "command": "select",
      "target": "id=select_leave_action_28",
      "targets": [],
      "value": "label=Approve"
    }, {
      "id": "5d3251f3-c30d-4e5d-9c35-2914ec05f662",
      "comment": "",
      "command": "click",
      "target": "id=select_leave_action_28",
      "targets": [
        ["id=select_leave_action_28", "id"],
        ["name=select_leave_action_28", "name"],
        ["css=#select_leave_action_28", "css:finder"],
        ["xpath=//select[@id='select_leave_action_28']", "xpath:attributes"],
        ["xpath=//table[@id='resultTable']/tbody/tr/td[8]/select", "xpath:idRelative"],
        ["xpath=//td[8]/select", "xpath:position"],
        ["xpath=//select[contains(.,'Select Action\nApprove\nCancel\nReject')]", "xpath:innerText"]
      ],
      "value": ""
    }, {
      "id": "275f957b-2860-4741-b62b-a780b3fdd617",
      "comment": "",
      "command": "click",
      "target": "id=btnSave",
      "targets": [
        ["id=btnSave", "id"],
        ["name=btnSave", "name"],
        ["css=#btnSave", "css:finder"],
        ["xpath=//input[@id='btnSave']", "xpath:attributes"],
        ["xpath=//form[@id='frmList_ohrmListComponent']/div[4]/input", "xpath:idRelative"],
        ["xpath=//div[4]/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "9b8e02b1-7480-4c75-a348-d3454fb6c5a7",
      "comment": "",
      "command": "close",
      "target": "",
      "targets": [],
      "value": ""
    }]
  }],
  "suites": [{
    "id": "1ddd1331-a59b-4b26-9db3-47ebc9d5a173",
    "name": "Default Suite",
    "persistSession": false,
    "parallel": false,
    "timeout": 300,
    "tests": ["2b73609c-7020-4e9c-88f0-6184309deca0"]
  }],
  "urls": ["https://opensource-demo.orangehrmlive.com/", "https://opensource-demo.orangehrmlive.com/index.php/recruitment/viewJobVacancy"],
  "plugins": []
}