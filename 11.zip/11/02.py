{
  "id": "7a5e5797-038b-4e18-8e1a-571822b241d4",
  "version": "2.0",
  "name": "ПР11",
  "url": "https://opensource-demo.orangehrmlive.com/",
  "tests": [{
    "id": "2b73609c-7020-4e9c-88f0-6184309deca0",
    "name": "Untitled",
    "commands": [{
      "id": "b3bd5205-eb3a-40fb-9744-3a5e5f186848",
      "comment": "",
      "command": "open",
      "target": "/",
      "targets": [],
      "value": ""
    }, {
      "id": "e25dcdd4-4cea-4aed-8120-cda6a7f1a4e0",
      "comment": "",
      "command": "setWindowSize",
      "target": "857x1040",
      "targets": [],
      "value": ""
    }, {
      "id": "39cee0dc-ea7d-4c7d-9413-e61d0bba8dc6",
      "comment": "",
      "command": "click",
      "target": "css=#divUsername > .form-hint",
      "targets": [
        ["css=#divUsername > .form-hint", "css:finder"],
        ["xpath=//div[@id='divUsername']/span", "xpath:idRelative"],
        ["xpath=//form/div[2]/span", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "18d954bc-80f1-40dd-a507-e9926f5d9eba",
      "comment": "",
      "command": "click",
      "target": "css=span:nth-child(1)",
      "targets": [
        ["css=span:nth-child(1)", "css:finder"],
        ["xpath=//div[@id='content']/div[2]/span", "xpath:idRelative"],
        ["xpath=//span", "xpath:position"],
        ["xpath=//span[contains(.,'( Username : Admin | Password : admin123 )')]", "xpath:innerText"]
      ],
      "value": ""
    }, {
      "id": "9bf653e8-7b00-47dc-9857-bf19d31a9ad8",
      "comment": "",
      "command": "click",
      "target": "id=txtUsername",
      "targets": [
        ["id=txtUsername", "id"],
        ["name=txtUsername", "name"],
        ["css=#txtUsername", "css:finder"],
        ["xpath=//input[@id='txtUsername']", "xpath:attributes"],
        ["xpath=//div[@id='divUsername']/input", "xpath:idRelative"],
        ["xpath=//div[2]/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "4efca12e-a143-4edc-bb9e-4e2565de20d6",
      "comment": "",
      "command": "type",
      "target": "id=txtUsername",
      "targets": [
        ["id=txtUsername", "id"],
        ["name=txtUsername", "name"],
        ["css=#txtUsername", "css:finder"],
        ["xpath=//input[@id='txtUsername']", "xpath:attributes"],
        ["xpath=//div[@id='divUsername']/input", "xpath:idRelative"],
        ["xpath=//div[2]/input", "xpath:position"]
      ],
      "value": "Admin"
    }, {
      "id": "ad890fd6-a9eb-4caa-ba52-85c250a4cf52",
      "comment": "",
      "command": "click",
      "target": "id=txtPassword",
      "targets": [
        ["id=txtPassword", "id"],
        ["name=txtPassword", "name"],
        ["css=#txtPassword", "css:finder"],
        ["xpath=//input[@id='txtPassword']", "xpath:attributes"],
        ["xpath=//div[@id='divPassword']/input", "xpath:idRelative"],
        ["xpath=//div[3]/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "29a46077-620b-4089-9527-173d8537971f",
      "comment": "",
      "command": "close",
      "target": "",
      "targets": [],
      "value": ""
    }]
  }, {
    "id": "df17e8bf-e8e7-4ea1-92af-cae71f156a49",
    "name": "ВХОД",
    "commands": [{
      "id": "4a839794-5fc3-4298-a3ab-7bde07eb12c5",
      "comment": "",
      "command": "open",
      "target": "https://opensource-demo.orangehrmlive.com/",
      "targets": [],
      "value": ""
    }, {
      "id": "f5369d83-c432-4dbe-9f70-3683a5c2a433",
      "comment": "",
      "command": "setWindowSize",
      "target": "857x1040",
      "targets": [],
      "value": ""
    }, {
      "id": "6515aad0-d0af-4495-8a0b-6b66d1c4e7fa",
      "comment": "",
      "command": "click",
      "target": "css=#divUsername > .form-hint",
      "targets": [
        ["css=#divUsername > .form-hint", "css:finder"],
        ["xpath=//div[@id='divUsername']/span", "xpath:idRelative"],
        ["xpath=//form/div[2]/span", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "05a2ea06-a435-4c37-baf9-2e2550f6bd04",
      "comment": "",
      "command": "type",
      "target": "id=txtUsername",
      "targets": [
        ["id=txtUsername", "id"],
        ["name=txtUsername", "name"],
        ["css=#txtUsername", "css:finder"],
        ["xpath=//input[@id='txtUsername']", "xpath:attributes"],
        ["xpath=//div[@id='divUsername']/input", "xpath:idRelative"],
        ["xpath=//div[2]/input", "xpath:position"]
      ],
      "value": "Admin"
    }, {
      "id": "0e0b2ba1-deb2-4861-b6c5-6865beb6d962",
      "comment": "",
      "command": "click",
      "target": "id=txtPassword",
      "targets": [
        ["id=txtPassword", "id"],
        ["name=txtPassword", "name"],
        ["css=#txtPassword", "css:finder"],
        ["xpath=//input[@id='txtPassword']", "xpath:attributes"],
        ["xpath=//div[@id='divPassword']/input", "xpath:idRelative"],
        ["xpath=//div[3]/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "5ac3c824-caed-491c-9479-dfdae5a28ad6",
      "comment": "",
      "command": "type",
      "target": "id=txtPassword",
      "targets": [
        ["id=txtPassword", "id"],
        ["name=txtPassword", "name"],
        ["css=#txtPassword", "css:finder"],
        ["xpath=//input[@id='txtPassword']", "xpath:attributes"],
        ["xpath=//div[@id='divPassword']/input", "xpath:idRelative"],
        ["xpath=//div[3]/input", "xpath:position"]
      ],
      "value": "admin123"
    }, {
      "id": "6f46926c-1482-43b3-a513-dc3237680fb9",
      "comment": "",
      "command": "click",
      "target": "id=btnLogin",
      "targets": [
        ["id=btnLogin", "id"],
        ["name=Submit", "name"],
        ["css=#btnLogin", "css:finder"],
        ["xpath=//input[@id='btnLogin']", "xpath:attributes"],
        ["xpath=//div[@id='divLoginButton']/input", "xpath:idRelative"],
        ["xpath=//div[5]/input", "xpath:position"]
      ],
      "value": ""
    }]
  }, {
    "id": "0d0acc0f-8382-4766-8fff-9b5be46123b8",
    "name": "02",
    "commands": [{
      "id": "018548cf-68c9-4840-9183-01081dcd7ff0",
      "comment": "",
      "command": "open",
      "target": "https://opensource-demo.orangehrmlive.com/index.php/dashboard",
      "targets": [],
      "value": ""
    }, {
      "id": "9d7bf8e3-7562-4b21-8fda-0758e42cd4a9",
      "comment": "",
      "command": "setWindowSize",
      "target": "1088x1040",
      "targets": [],
      "value": ""
    }, {
      "id": "5b89ea95-083e-47a8-abe7-ee82db0e8320",
      "comment": "",
      "command": "click",
      "target": "css=td:nth-child(1) img",
      "targets": [
        ["css=td:nth-child(1) img", "css:finder"],
        ["xpath=//div[@id='dashboard-quick-launch-panel-menu_holder']/table/tbody/tr/td/div/a/img", "xpath:idRelative"],
        ["xpath=//td/div/a/img", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "77191833-d6e9-4fe7-8452-0ce18881b426",
      "comment": "",
      "command": "click",
      "target": "css=#menu_pim_viewMyDetails > b",
      "targets": [
        ["css=#menu_pim_viewMyDetails > b", "css:finder"],
        ["xpath=//a[@id='menu_pim_viewMyDetails']/b", "xpath:idRelative"],
        ["xpath=//li[6]/a/b", "xpath:position"],
        ["xpath=//b[contains(.,'My Info')]", "xpath:innerText"]
      ],
      "value": ""
    }, {
      "id": "8adda7c2-fa33-4055-a3ca-73a8c4490a07",
      "comment": "",
      "command": "click",
      "target": "id=empPic",
      "targets": [
        ["id=empPic", "id"],
        ["css=#empPic", "css:finder"],
        ["xpath=//img[@alt='Employee Photo']", "xpath:img"],
        ["xpath=//img[@id='empPic']", "xpath:attributes"],
        ["xpath=//div[@id='profile-pic']/div/a/img", "xpath:idRelative"],
        ["xpath=//div/div/div/a/img", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "ed0e9b8f-1df1-410a-8da1-70a2e8dfa294",
      "comment": "",
      "command": "click",
      "target": "id=photofile",
      "targets": [
        ["id=photofile", "id"],
        ["name=photofile", "name"],
        ["css=#photofile", "css:finder"],
        ["xpath=//input[@id='photofile']", "xpath:attributes"],
        ["xpath=//form[@id='frmPhoto']/fieldset/ol/li/input", "xpath:idRelative"],
        ["xpath=//li/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "ec5a2e58-5e2b-4823-8fe0-d8652ea44c6d",
      "comment": "",
      "command": "type",
      "target": "id=photofile",
      "targets": [
        ["id=photofile", "id"],
        ["name=photofile", "name"],
        ["css=#photofile", "css:finder"],
        ["xpath=//input[@id='photofile']", "xpath:attributes"],
        ["xpath=//form[@id='frmPhoto']/fieldset/ol/li/input", "xpath:idRelative"],
        ["xpath=//li/input", "xpath:position"]
      ],
      "value": "C:\\fakepath\\5bbbfe289f0d3-thumbnail.jpg"
    }, {
      "id": "6f653c10-52e2-43ec-bcb3-f54cfaba68a8",
      "comment": "",
      "command": "click",
      "target": "id=btnSave",
      "targets": [
        ["id=btnSave", "id"],
        ["css=#btnSave", "css:finder"],
        ["xpath=//input[@id='btnSave']", "xpath:attributes"],
        ["xpath=//form[@id='frmPhoto']/fieldset/p/input", "xpath:idRelative"],
        ["xpath=//p/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "2e329722-3720-4a51-8f6e-7f8dc66417e2",
      "comment": "",
      "command": "close",
      "target": "",
      "targets": [],
      "value": ""
    }]
  }],
  "suites": [{
    "id": "1ddd1331-a59b-4b26-9db3-47ebc9d5a173",
    "name": "Default Suite",
    "persistSession": false,
    "parallel": false,
    "timeout": 300,
    "tests": ["2b73609c-7020-4e9c-88f0-6184309deca0"]
  }],
  "urls": ["https://opensource-demo.orangehrmlive.com/"],
  "plugins": []
}