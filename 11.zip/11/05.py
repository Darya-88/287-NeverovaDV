{
  "id": "7a5e5797-038b-4e18-8e1a-571822b241d4",
  "version": "2.0",
  "name": "ПР11",
  "url": "https://opensource-demo.orangehrmlive.com/",
  "tests": [{
    "id": "2b73609c-7020-4e9c-88f0-6184309deca0",
    "name": "Untitled",
    "commands": [{
      "id": "b3bd5205-eb3a-40fb-9744-3a5e5f186848",
      "comment": "",
      "command": "open",
      "target": "/",
      "targets": [],
      "value": ""
    }, {
      "id": "e25dcdd4-4cea-4aed-8120-cda6a7f1a4e0",
      "comment": "",
      "command": "setWindowSize",
      "target": "857x1040",
      "targets": [],
      "value": ""
    }, {
      "id": "39cee0dc-ea7d-4c7d-9413-e61d0bba8dc6",
      "comment": "",
      "command": "click",
      "target": "css=#divUsername > .form-hint",
      "targets": [
        ["css=#divUsername > .form-hint", "css:finder"],
        ["xpath=//div[@id='divUsername']/span", "xpath:idRelative"],
        ["xpath=//form/div[2]/span", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "18d954bc-80f1-40dd-a507-e9926f5d9eba",
      "comment": "",
      "command": "click",
      "target": "css=span:nth-child(1)",
      "targets": [
        ["css=span:nth-child(1)", "css:finder"],
        ["xpath=//div[@id='content']/div[2]/span", "xpath:idRelative"],
        ["xpath=//span", "xpath:position"],
        ["xpath=//span[contains(.,'( Username : Admin | Password : admin123 )')]", "xpath:innerText"]
      ],
      "value": ""
    }, {
      "id": "9bf653e8-7b00-47dc-9857-bf19d31a9ad8",
      "comment": "",
      "command": "click",
      "target": "id=txtUsername",
      "targets": [
        ["id=txtUsername", "id"],
        ["name=txtUsername", "name"],
        ["css=#txtUsername", "css:finder"],
        ["xpath=//input[@id='txtUsername']", "xpath:attributes"],
        ["xpath=//div[@id='divUsername']/input", "xpath:idRelative"],
        ["xpath=//div[2]/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "4efca12e-a143-4edc-bb9e-4e2565de20d6",
      "comment": "",
      "command": "type",
      "target": "id=txtUsername",
      "targets": [
        ["id=txtUsername", "id"],
        ["name=txtUsername", "name"],
        ["css=#txtUsername", "css:finder"],
        ["xpath=//input[@id='txtUsername']", "xpath:attributes"],
        ["xpath=//div[@id='divUsername']/input", "xpath:idRelative"],
        ["xpath=//div[2]/input", "xpath:position"]
      ],
      "value": "Admin"
    }, {
      "id": "ad890fd6-a9eb-4caa-ba52-85c250a4cf52",
      "comment": "",
      "command": "click",
      "target": "id=txtPassword",
      "targets": [
        ["id=txtPassword", "id"],
        ["name=txtPassword", "name"],
        ["css=#txtPassword", "css:finder"],
        ["xpath=//input[@id='txtPassword']", "xpath:attributes"],
        ["xpath=//div[@id='divPassword']/input", "xpath:idRelative"],
        ["xpath=//div[3]/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "29a46077-620b-4089-9527-173d8537971f",
      "comment": "",
      "command": "close",
      "target": "",
      "targets": [],
      "value": ""
    }]
  }, {
    "id": "df17e8bf-e8e7-4ea1-92af-cae71f156a49",
    "name": "ВХОД",
    "commands": [{
      "id": "4a839794-5fc3-4298-a3ab-7bde07eb12c5",
      "comment": "",
      "command": "open",
      "target": "https://opensource-demo.orangehrmlive.com/",
      "targets": [],
      "value": ""
    }, {
      "id": "f5369d83-c432-4dbe-9f70-3683a5c2a433",
      "comment": "",
      "command": "setWindowSize",
      "target": "857x1040",
      "targets": [],
      "value": ""
    }, {
      "id": "6515aad0-d0af-4495-8a0b-6b66d1c4e7fa",
      "comment": "",
      "command": "click",
      "target": "css=#divUsername > .form-hint",
      "targets": [
        ["css=#divUsername > .form-hint", "css:finder"],
        ["xpath=//div[@id='divUsername']/span", "xpath:idRelative"],
        ["xpath=//form/div[2]/span", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "05a2ea06-a435-4c37-baf9-2e2550f6bd04",
      "comment": "",
      "command": "type",
      "target": "id=txtUsername",
      "targets": [
        ["id=txtUsername", "id"],
        ["name=txtUsername", "name"],
        ["css=#txtUsername", "css:finder"],
        ["xpath=//input[@id='txtUsername']", "xpath:attributes"],
        ["xpath=//div[@id='divUsername']/input", "xpath:idRelative"],
        ["xpath=//div[2]/input", "xpath:position"]
      ],
      "value": "Admin"
    }, {
      "id": "0e0b2ba1-deb2-4861-b6c5-6865beb6d962",
      "comment": "",
      "command": "click",
      "target": "id=txtPassword",
      "targets": [
        ["id=txtPassword", "id"],
        ["name=txtPassword", "name"],
        ["css=#txtPassword", "css:finder"],
        ["xpath=//input[@id='txtPassword']", "xpath:attributes"],
        ["xpath=//div[@id='divPassword']/input", "xpath:idRelative"],
        ["xpath=//div[3]/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "5ac3c824-caed-491c-9479-dfdae5a28ad6",
      "comment": "",
      "command": "type",
      "target": "id=txtPassword",
      "targets": [
        ["id=txtPassword", "id"],
        ["name=txtPassword", "name"],
        ["css=#txtPassword", "css:finder"],
        ["xpath=//input[@id='txtPassword']", "xpath:attributes"],
        ["xpath=//div[@id='divPassword']/input", "xpath:idRelative"],
        ["xpath=//div[3]/input", "xpath:position"]
      ],
      "value": "admin123"
    }, {
      "id": "6f46926c-1482-43b3-a513-dc3237680fb9",
      "comment": "",
      "command": "click",
      "target": "id=btnLogin",
      "targets": [
        ["id=btnLogin", "id"],
        ["name=Submit", "name"],
        ["css=#btnLogin", "css:finder"],
        ["xpath=//input[@id='btnLogin']", "xpath:attributes"],
        ["xpath=//div[@id='divLoginButton']/input", "xpath:idRelative"],
        ["xpath=//div[5]/input", "xpath:position"]
      ],
      "value": ""
    }]
  }, {
    "id": "0d0acc0f-8382-4766-8fff-9b5be46123b8",
    "name": "02",
    "commands": [{
      "id": "018548cf-68c9-4840-9183-01081dcd7ff0",
      "comment": "",
      "command": "open",
      "target": "https://opensource-demo.orangehrmlive.com/index.php/dashboard",
      "targets": [],
      "value": ""
    }, {
      "id": "9d7bf8e3-7562-4b21-8fda-0758e42cd4a9",
      "comment": "",
      "command": "setWindowSize",
      "target": "1088x1040",
      "targets": [],
      "value": ""
    }, {
      "id": "5b89ea95-083e-47a8-abe7-ee82db0e8320",
      "comment": "",
      "command": "click",
      "target": "css=td:nth-child(1) img",
      "targets": [
        ["css=td:nth-child(1) img", "css:finder"],
        ["xpath=//div[@id='dashboard-quick-launch-panel-menu_holder']/table/tbody/tr/td/div/a/img", "xpath:idRelative"],
        ["xpath=//td/div/a/img", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "77191833-d6e9-4fe7-8452-0ce18881b426",
      "comment": "",
      "command": "click",
      "target": "css=#menu_pim_viewMyDetails > b",
      "targets": [
        ["css=#menu_pim_viewMyDetails > b", "css:finder"],
        ["xpath=//a[@id='menu_pim_viewMyDetails']/b", "xpath:idRelative"],
        ["xpath=//li[6]/a/b", "xpath:position"],
        ["xpath=//b[contains(.,'My Info')]", "xpath:innerText"]
      ],
      "value": ""
    }, {
      "id": "8adda7c2-fa33-4055-a3ca-73a8c4490a07",
      "comment": "",
      "command": "click",
      "target": "id=empPic",
      "targets": [
        ["id=empPic", "id"],
        ["css=#empPic", "css:finder"],
        ["xpath=//img[@alt='Employee Photo']", "xpath:img"],
        ["xpath=//img[@id='empPic']", "xpath:attributes"],
        ["xpath=//div[@id='profile-pic']/div/a/img", "xpath:idRelative"],
        ["xpath=//div/div/div/a/img", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "ed0e9b8f-1df1-410a-8da1-70a2e8dfa294",
      "comment": "",
      "command": "click",
      "target": "id=photofile",
      "targets": [
        ["id=photofile", "id"],
        ["name=photofile", "name"],
        ["css=#photofile", "css:finder"],
        ["xpath=//input[@id='photofile']", "xpath:attributes"],
        ["xpath=//form[@id='frmPhoto']/fieldset/ol/li/input", "xpath:idRelative"],
        ["xpath=//li/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "ec5a2e58-5e2b-4823-8fe0-d8652ea44c6d",
      "comment": "",
      "command": "type",
      "target": "id=photofile",
      "targets": [
        ["id=photofile", "id"],
        ["name=photofile", "name"],
        ["css=#photofile", "css:finder"],
        ["xpath=//input[@id='photofile']", "xpath:attributes"],
        ["xpath=//form[@id='frmPhoto']/fieldset/ol/li/input", "xpath:idRelative"],
        ["xpath=//li/input", "xpath:position"]
      ],
      "value": "C:\\fakepath\\5bbbfe289f0d3-thumbnail.jpg"
    }, {
      "id": "6f653c10-52e2-43ec-bcb3-f54cfaba68a8",
      "comment": "",
      "command": "click",
      "target": "id=btnSave",
      "targets": [
        ["id=btnSave", "id"],
        ["css=#btnSave", "css:finder"],
        ["xpath=//input[@id='btnSave']", "xpath:attributes"],
        ["xpath=//form[@id='frmPhoto']/fieldset/p/input", "xpath:idRelative"],
        ["xpath=//p/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "2e329722-3720-4a51-8f6e-7f8dc66417e2",
      "comment": "",
      "command": "close",
      "target": "",
      "targets": [],
      "value": ""
    }]
  }, {
    "id": "69cbad02-03a7-4003-81ad-a5459b22643b",
    "name": "03",
    "commands": [{
      "id": "5ee625d6-de8d-41c2-9ebe-867f0b4fe2fe",
      "comment": "",
      "command": "open",
      "target": "https://opensource-demo.orangehrmlive.com/index.php/dashboard",
      "targets": [],
      "value": ""
    }, {
      "id": "24df5bb0-7c7b-4e50-8072-5b411f298b87",
      "comment": "",
      "command": "setWindowSize",
      "target": "857x1040",
      "targets": [],
      "value": ""
    }, {
      "id": "9c959a6b-9e99-4b5f-a925-c5ffe10d0efc",
      "comment": "",
      "command": "click",
      "target": "css=#menu_pim_viewMyDetails > b",
      "targets": [
        ["css=#menu_pim_viewMyDetails > b", "css:finder"],
        ["xpath=//a[@id='menu_pim_viewMyDetails']/b", "xpath:idRelative"],
        ["xpath=//li[6]/a/b", "xpath:position"],
        ["xpath=//b[contains(.,'My Info')]", "xpath:innerText"]
      ],
      "value": ""
    }, {
      "id": "1f20a58a-a697-452d-bb7b-eed729c60de4",
      "comment": "",
      "command": "click",
      "target": "id=personal_txtEmpFirstName",
      "targets": [
        ["id=personal_txtEmpFirstName", "id"],
        ["name=personal[txtEmpFirstName]", "name"],
        ["css=#personal_txtEmpFirstName", "css:finder"],
        ["xpath=//input[@id='personal_txtEmpFirstName']", "xpath:attributes"],
        ["xpath=//form[@id='frmEmpPersonalDetails']/fieldset/ol/li/ol/li/input", "xpath:idRelative"],
        ["xpath=//li/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "d56d0715-00bc-4d91-b540-81c89579855d",
      "comment": "",
      "command": "click",
      "target": "id=personal_txtEmpFirstName",
      "targets": [
        ["id=personal_txtEmpFirstName", "id"],
        ["name=personal[txtEmpFirstName]", "name"],
        ["css=#personal_txtEmpFirstName", "css:finder"],
        ["xpath=//input[@id='personal_txtEmpFirstName']", "xpath:attributes"],
        ["xpath=//form[@id='frmEmpPersonalDetails']/fieldset/ol/li/ol/li/input", "xpath:idRelative"],
        ["xpath=//li/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "17753eaa-7dd4-4d03-8c76-5a4aff357f8e",
      "comment": "",
      "command": "click",
      "target": "id=personal_txtEmpFirstName",
      "targets": [
        ["id=personal_txtEmpFirstName", "id"],
        ["name=personal[txtEmpFirstName]", "name"],
        ["css=#personal_txtEmpFirstName", "css:finder"],
        ["xpath=//input[@id='personal_txtEmpFirstName']", "xpath:attributes"],
        ["xpath=//form[@id='frmEmpPersonalDetails']/fieldset/ol/li/ol/li/input", "xpath:idRelative"],
        ["xpath=//li/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "b4dda835-acc4-4ad7-b85c-bc83095d4261",
      "comment": "",
      "command": "click",
      "target": "id=personal_txtEmpFirstName",
      "targets": [
        ["id=personal_txtEmpFirstName", "id"],
        ["name=personal[txtEmpFirstName]", "name"],
        ["css=#personal_txtEmpFirstName", "css:finder"],
        ["xpath=//input[@id='personal_txtEmpFirstName']", "xpath:attributes"],
        ["xpath=//form[@id='frmEmpPersonalDetails']/fieldset/ol/li/ol/li/input", "xpath:idRelative"],
        ["xpath=//li/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "e82333a7-35bb-4e17-a44b-cd30f5d127e1",
      "comment": "",
      "command": "click",
      "target": "id=personal_txtEmpLastName",
      "targets": [
        ["id=personal_txtEmpLastName", "id"],
        ["name=personal[txtEmpLastName]", "name"],
        ["css=#personal_txtEmpLastName", "css:finder"],
        ["xpath=//input[@id='personal_txtEmpLastName']", "xpath:attributes"],
        ["xpath=//form[@id='frmEmpPersonalDetails']/fieldset/ol/li/ol/li[3]/input", "xpath:idRelative"],
        ["xpath=//li[3]/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "841b1c1e-b6f5-47a0-8fcf-6babc35d6b75",
      "comment": "",
      "command": "click",
      "target": "id=personal_txtEmpMiddleName",
      "targets": [
        ["id=personal_txtEmpMiddleName", "id"],
        ["name=personal[txtEmpMiddleName]", "name"],
        ["css=#personal_txtEmpMiddleName", "css:finder"],
        ["xpath=//input[@id='personal_txtEmpMiddleName']", "xpath:attributes"],
        ["xpath=//form[@id='frmEmpPersonalDetails']/fieldset/ol/li/ol/li[2]/input", "xpath:idRelative"],
        ["xpath=//li[2]/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "d8ac6659-7eb6-4d23-9b07-5bd9b657da73",
      "comment": "",
      "command": "click",
      "target": "id=btnSave",
      "targets": [
        ["id=btnSave", "id"],
        ["css=#btnSave", "css:finder"],
        ["xpath=//input[@id='btnSave']", "xpath:attributes"],
        ["xpath=//form[@id='frmEmpPersonalDetails']/fieldset/p/input", "xpath:idRelative"],
        ["xpath=//p/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "011f9286-67b1-41dc-aa73-c95c4510403d",
      "comment": "",
      "command": "click",
      "target": "id=personal_txtEmpMiddleName",
      "targets": [
        ["id=personal_txtEmpMiddleName", "id"],
        ["name=personal[txtEmpMiddleName]", "name"],
        ["css=#personal_txtEmpMiddleName", "css:finder"],
        ["xpath=//input[@id='personal_txtEmpMiddleName']", "xpath:attributes"],
        ["xpath=//form[@id='frmEmpPersonalDetails']/fieldset/ol/li/ol/li[2]/input", "xpath:idRelative"],
        ["xpath=//li[2]/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "9a2dd1fb-1ca0-4604-ac90-1086aabcdfe8",
      "comment": "",
      "command": "click",
      "target": "id=personal_txtEmpFirstName",
      "targets": [
        ["id=personal_txtEmpFirstName", "id"],
        ["name=personal[txtEmpFirstName]", "name"],
        ["css=#personal_txtEmpFirstName", "css:finder"],
        ["xpath=//input[@id='personal_txtEmpFirstName']", "xpath:attributes"],
        ["xpath=//form[@id='frmEmpPersonalDetails']/fieldset/ol/li/ol/li/input", "xpath:idRelative"],
        ["xpath=//li/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "01f17271-d147-4d1e-96c8-bbf0de5f17ff",
      "comment": "",
      "command": "type",
      "target": "id=personal_txtEmpFirstName",
      "targets": [
        ["id=personal_txtEmpFirstName", "id"],
        ["name=personal[txtEmpFirstName]", "name"],
        ["css=#personal_txtEmpFirstName", "css:finder"],
        ["xpath=//input[@id='personal_txtEmpFirstName']", "xpath:attributes"],
        ["xpath=//form[@id='frmEmpPersonalDetails']/fieldset/ol/li/ol/li/input", "xpath:idRelative"],
        ["xpath=//li/input", "xpath:position"]
      ],
      "value": "faul"
    }, {
      "id": "5422502e-8e76-4fc5-8aa4-bb79513fad25",
      "comment": "",
      "command": "click",
      "target": "id=btnSave",
      "targets": [
        ["id=btnSave", "id"],
        ["css=#btnSave", "css:finder"],
        ["xpath=//input[@id='btnSave']", "xpath:attributes"],
        ["xpath=//form[@id='frmEmpPersonalDetails']/fieldset/p/input", "xpath:idRelative"],
        ["xpath=//p/input", "xpath:position"]
      ],
      "value": ""
    }]
  }, {
    "id": "8f640f9c-251e-40f9-ac6e-22bc61ee4650",
    "name": "04",
    "commands": [{
      "id": "a23b9e30-7092-4325-ad1a-ebf755a2deaf",
      "comment": "",
      "command": "open",
      "target": "https://opensource-demo.orangehrmlive.com/index.php/dashboard",
      "targets": [],
      "value": ""
    }, {
      "id": "8689bc84-3a48-4f8d-8aa0-42c1705670d5",
      "comment": "",
      "command": "setWindowSize",
      "target": "857x1040",
      "targets": [],
      "value": ""
    }, {
      "id": "60a2a530-0539-41fd-9573-b48814150184",
      "comment": "",
      "command": "click",
      "target": "css=.inner",
      "targets": [
        ["css=.inner", "css:finder"],
        ["xpath=//div[@id='content']/div/div[2]", "xpath:idRelative"],
        ["xpath=//body/div/div[3]/div/div[2]", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "6c8cc4be-de23-4d81-9fa5-27f440b50d35",
      "comment": "",
      "command": "click",
      "target": "css=#menu_recruitment_viewRecruitmentModule font > font",
      "targets": [
        ["css=#menu_recruitment_viewRecruitmentModule font > font", "css:finder"],
        ["xpath=//a[@id='menu_recruitment_viewRecruitmentModule']/b/font/font", "xpath:idRelative"],
        ["xpath=//li[5]/a/b/font/font", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "9535aa4e-f445-4064-94b6-3ace96662645",
      "comment": "",
      "command": "click",
      "target": "id=candidateSearch_jobTitle",
      "targets": [
        ["id=candidateSearch_jobTitle", "id"],
        ["name=candidateSearch[jobTitle]", "name"],
        ["css=#candidateSearch_jobTitle", "css:finder"],
        ["xpath=//select[@id='candidateSearch_jobTitle']", "xpath:attributes"],
        ["xpath=//form[@id='frmSrchCandidates']/fieldset/ol/li/select", "xpath:idRelative"],
        ["xpath=//select", "xpath:position"],
        ["xpath=//select[contains(.,'Все\nБухгалтер\nАналитик\nаналитик\nДиректор компании\nГлавный финансовый директор\nГлавный инженер\nконсультироваться\nСпециалист по содержанию\nМенеджер по работе с клиентами\nАдминистратор базы данных\nФинансовый менеджер\nФинансовый аналитик\nРуководитель службы поддержки\nСпециалист по персоналу\nМенеджер по персоналу\nИТ-менеджер\nСетевой администратор\nАдминистратор расчета заработной платы\nКоординатор предпродажной подготовки\nИнженер QA\nQA Lead\nТорговый представитель\nСтарший аналитик\nМаркетолог в социальных сетях\nАрхитектор программного обеспечения\nПрограммист\nСпециалист службы поддержки\nТест-аналитик\nинженер-испытатель\nВице-президент по обслуживанию клиентов\nВице-президент по продажам и маркетингу')]", "xpath:innerText"]
      ],
      "value": ""
    }, {
      "id": "62134a44-f09e-47a2-bfa0-1b1cc9b15cf1",
      "comment": "",
      "command": "select",
      "target": "id=candidateSearch_jobTitle",
      "targets": [],
      "value": "label=Бухгалтер"
    }, {
      "id": "7d3bfeb1-89ae-42d6-a0ae-083e4c992cf9",
      "comment": "",
      "command": "click",
      "target": "id=candidateSearch_jobTitle",
      "targets": [
        ["id=candidateSearch_jobTitle", "id"],
        ["name=candidateSearch[jobTitle]", "name"],
        ["css=#candidateSearch_jobTitle", "css:finder"],
        ["xpath=//select[@id='candidateSearch_jobTitle']", "xpath:attributes"],
        ["xpath=//form[@id='frmSrchCandidates']/fieldset/ol/li/select", "xpath:idRelative"],
        ["xpath=//select", "xpath:position"],
        ["xpath=//select[contains(.,'Все\nБухгалтер\nАналитик\nаналитик\nДиректор компании\nГлавный финансовый директор\nГлавный инженер\nконсультироваться\nСпециалист по содержанию\nМенеджер по работе с клиентами\nАдминистратор базы данных\nФинансовый менеджер\nФинансовый аналитик\nРуководитель службы поддержки\nСпециалист по персоналу\nМенеджер по персоналу\nИТ-менеджер\nСетевой администратор\nАдминистратор расчета заработной платы\nКоординатор предпродажной подготовки\nИнженер QA\nQA Lead\nТорговый представитель\nСтарший аналитик\nМаркетолог в социальных сетях\nАрхитектор программного обеспечения\nПрограммист\nСпециалист службы поддержки\nТест-аналитик\nинженер-испытатель\nВице-президент по обслуживанию клиентов\nВице-президент по продажам и маркетингу')]", "xpath:innerText"]
      ],
      "value": ""
    }, {
      "id": "6e3ba95a-0654-4b30-a4d4-e4200c35685c",
      "comment": "",
      "command": "click",
      "target": "id=candidateSearch_jobVacancy",
      "targets": [
        ["id=candidateSearch_jobVacancy", "id"],
        ["name=candidateSearch[jobVacancy]", "name"],
        ["css=#candidateSearch_jobVacancy", "css:finder"],
        ["xpath=//select[@id='candidateSearch_jobVacancy']", "xpath:attributes"],
        ["xpath=//form[@id='frmSrchCandidates']/fieldset/ol/li[2]/select", "xpath:idRelative"],
        ["xpath=//li[2]/select", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "a97889c7-9e3e-49dc-b194-5151ee65e13d",
      "comment": "",
      "command": "select",
      "target": "id=candidateSearch_jobVacancy",
      "targets": [],
      "value": "label=Junior Account Assistant"
    }, {
      "id": "dddff23e-1dfd-48a7-9641-9ed02f51497a",
      "comment": "",
      "command": "click",
      "target": "id=candidateSearch_jobVacancy",
      "targets": [
        ["id=candidateSearch_jobVacancy", "id"],
        ["name=candidateSearch[jobVacancy]", "name"],
        ["css=#candidateSearch_jobVacancy", "css:finder"],
        ["xpath=//select[@id='candidateSearch_jobVacancy']", "xpath:attributes"],
        ["xpath=//form[@id='frmSrchCandidates']/fieldset/ol/li[2]/select", "xpath:idRelative"],
        ["xpath=//li[2]/select", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "00bc3d4b-f073-40e3-9f27-b1328d68cd51",
      "comment": "",
      "command": "click",
      "target": "id=candidateSearch_jobVacancy",
      "targets": [
        ["id=candidateSearch_jobVacancy", "id"],
        ["name=candidateSearch[jobVacancy]", "name"],
        ["css=#candidateSearch_jobVacancy", "css:finder"],
        ["xpath=//select[@id='candidateSearch_jobVacancy']", "xpath:attributes"],
        ["xpath=//form[@id='frmSrchCandidates']/fieldset/ol/li[2]/select", "xpath:idRelative"],
        ["xpath=//li[2]/select", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "fa9623a8-037e-438c-b971-e2aeb8516ed4",
      "comment": "",
      "command": "select",
      "target": "id=candidateSearch_jobVacancy",
      "targets": [],
      "value": "label=All"
    }, {
      "id": "8e60cdef-1a36-45a2-9a92-bd0df6ec9646",
      "comment": "",
      "command": "click",
      "target": "id=candidateSearch_jobVacancy",
      "targets": [
        ["id=candidateSearch_jobVacancy", "id"],
        ["name=candidateSearch[jobVacancy]", "name"],
        ["css=#candidateSearch_jobVacancy", "css:finder"],
        ["xpath=//select[@id='candidateSearch_jobVacancy']", "xpath:attributes"],
        ["xpath=//form[@id='frmSrchCandidates']/fieldset/ol/li[2]/select", "xpath:idRelative"],
        ["xpath=//li[2]/select", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "e619e658-f0b4-41cc-8c83-ab0f97dccbe2",
      "comment": "",
      "command": "click",
      "target": "id=candidateSearch_keywords",
      "targets": [
        ["id=candidateSearch_keywords", "id"],
        ["name=candidateSearch[keywords]", "name"],
        ["css=#candidateSearch_keywords", "css:finder"],
        ["xpath=//input[@id='candidateSearch_keywords']", "xpath:attributes"],
        ["xpath=//form[@id='frmSrchCandidates']/fieldset/ol/li[6]/input", "xpath:idRelative"],
        ["xpath=//li[6]/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "79d326cb-c703-4a51-94d0-dc953f047ec7",
      "comment": "",
      "command": "click",
      "target": "id=candidateSearch_fromDate",
      "targets": [
        ["id=candidateSearch_fromDate", "id"],
        ["name=candidateSearch[dateApplication][from]", "name"],
        ["css=#candidateSearch_fromDate", "css:finder"],
        ["xpath=//input[@id='candidateSearch_fromDate']", "xpath:attributes"],
        ["xpath=//form[@id='frmSrchCandidates']/fieldset/ol/li[7]/input", "xpath:idRelative"],
        ["xpath=//li[7]/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "1584bcf5-2321-440d-9d00-5630032edf4b",
      "comment": "",
      "command": "click",
      "target": "linkText=18",
      "targets": [
        ["linkText=18", "linkText"],
        ["css=.ui-state-hover", "css:finder"],
        ["xpath=//div[@id='ui-datepicker-div']/table/tbody/tr[4]/td[3]/a", "xpath:idRelative"],
        ["xpath=(//a[contains(@href, '#')])[38]", "xpath:href"],
        ["xpath=//div[3]/table/tbody/tr[4]/td[3]/a", "xpath:position"],
        ["xpath=//a[contains(.,'18')]", "xpath:innerText"]
      ],
      "value": ""
    }, {
      "id": "6114eaee-eb1c-47c1-971b-76782e80534e",
      "comment": "",
      "command": "mouseOver",
      "target": "linkText=11",
      "targets": [
        ["linkText=11", "linkText"],
        ["css=.ui-state-fullday:nth-child(3) > .ui-state-default", "css:finder"],
        ["xpath=//div[@id='ui-datepicker-div']/table/tbody/tr[3]/td[3]/a", "xpath:idRelative"],
        ["xpath=(//a[contains(@href, '#')])[31]", "xpath:href"],
        ["xpath=//div[3]/table/tbody/tr[3]/td[3]/a", "xpath:position"],
        ["xpath=//a[contains(.,'11')]", "xpath:innerText"]
      ],
      "value": ""
    }, {
      "id": "e0c9a575-408c-4a73-ac14-dfdd2338c6fa",
      "comment": "",
      "command": "click",
      "target": "id=candidateSearch_fromDate",
      "targets": [
        ["id=candidateSearch_fromDate", "id"],
        ["name=candidateSearch[dateApplication][from]", "name"],
        ["css=#candidateSearch_fromDate", "css:finder"],
        ["xpath=//input[@id='candidateSearch_fromDate']", "xpath:attributes"],
        ["xpath=//form[@id='frmSrchCandidates']/fieldset/ol/li[7]/input", "xpath:idRelative"],
        ["xpath=//li[7]/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "55d5b2ff-b53a-4d74-9b89-cf73158e90bb",
      "comment": "",
      "command": "click",
      "target": "linkText=2",
      "targets": [
        ["linkText=2", "linkText"],
        ["css=.ui-state-hover", "css:finder"],
        ["xpath=//div[@id='ui-datepicker-div']/table/tbody/tr[2]/td/a", "xpath:idRelative"],
        ["xpath=(//a[contains(@href, '#')])[22]", "xpath:href"],
        ["xpath=//div[3]/table/tbody/tr[2]/td/a", "xpath:position"],
        ["xpath=//a[contains(.,'2')]", "xpath:innerText"]
      ],
      "value": ""
    }, {
      "id": "9b2fc654-0810-4471-a365-ce7c6d0fadad",
      "comment": "",
      "command": "click",
      "target": "id=candidateSearch_fromDate",
      "targets": [
        ["id=candidateSearch_fromDate", "id"],
        ["name=candidateSearch[dateApplication][from]", "name"],
        ["css=#candidateSearch_fromDate", "css:finder"],
        ["xpath=//input[@id='candidateSearch_fromDate']", "xpath:attributes"],
        ["xpath=//form[@id='frmSrchCandidates']/fieldset/ol/li[7]/input", "xpath:idRelative"],
        ["xpath=//li[7]/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "aab1e122-37b4-43c9-97d9-5411e2fa6e8a",
      "comment": "",
      "command": "click",
      "target": "linkText=2",
      "targets": [
        ["linkText=2", "linkText"],
        ["css=.ui-state-hover", "css:finder"],
        ["xpath=//div[@id='ui-datepicker-div']/table/tbody/tr[2]/td/a", "xpath:idRelative"],
        ["xpath=(//a[contains(@href, '#')])[22]", "xpath:href"],
        ["xpath=//div[3]/table/tbody/tr[2]/td/a", "xpath:position"],
        ["xpath=//a[contains(.,'2')]", "xpath:innerText"]
      ],
      "value": ""
    }, {
      "id": "d489cf3e-098b-4643-bbff-5075299efec0",
      "comment": "",
      "command": "click",
      "target": "id=candidateSearch_fromDate",
      "targets": [
        ["id=candidateSearch_fromDate", "id"],
        ["name=candidateSearch[dateApplication][from]", "name"],
        ["css=#candidateSearch_fromDate", "css:finder"],
        ["xpath=//input[@id='candidateSearch_fromDate']", "xpath:attributes"],
        ["xpath=//form[@id='frmSrchCandidates']/fieldset/ol/li[7]/input", "xpath:idRelative"],
        ["xpath=//li[7]/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "07fbd20a-73b0-4d69-b274-ceadf920e524",
      "comment": "",
      "command": "click",
      "target": "css=.ui-datepicker-month",
      "targets": [
        ["css=.ui-datepicker-month", "css:finder"],
        ["xpath=//div[@id='ui-datepicker-div']/div/div/select", "xpath:idRelative"],
        ["xpath=//div/select", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "ee543484-3e09-4f2a-ace6-4172d1a19541",
      "comment": "",
      "command": "click",
      "target": "linkText=3",
      "targets": [
        ["linkText=3", "linkText"],
        ["css=.ui-state-hover", "css:finder"],
        ["xpath=//div[@id='ui-datepicker-div']/table/tbody/tr[2]/td[2]/a", "xpath:idRelative"],
        ["xpath=(//a[contains(@href, '#')])[23]", "xpath:href"],
        ["xpath=//td[2]/a", "xpath:position"],
        ["xpath=//a[contains(.,'3')]", "xpath:innerText"]
      ],
      "value": ""
    }, {
      "id": "954853c2-9684-4ace-825c-4c6afd0b56d1",
      "comment": "",
      "command": "click",
      "target": "id=candidateSearch_fromDate",
      "targets": [
        ["id=candidateSearch_fromDate", "id"],
        ["name=candidateSearch[dateApplication][from]", "name"],
        ["css=#candidateSearch_fromDate", "css:finder"],
        ["xpath=//input[@id='candidateSearch_fromDate']", "xpath:attributes"],
        ["xpath=//form[@id='frmSrchCandidates']/fieldset/ol/li[7]/input", "xpath:idRelative"],
        ["xpath=//li[7]/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "99779cbf-98a9-4655-8bb1-a1e242b34816",
      "comment": "",
      "command": "click",
      "target": "css=.ui-datepicker-year",
      "targets": [
        ["css=.ui-datepicker-year", "css:finder"],
        ["xpath=//div[@id='ui-datepicker-div']/div/div/select[2]", "xpath:idRelative"],
        ["xpath=//select[2]", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "3ef52f4f-b48f-49e2-a63c-5a5909495162",
      "comment": "",
      "command": "click",
      "target": "css=.ui-datepicker-year",
      "targets": [
        ["css=.ui-datepicker-year", "css:finder"],
        ["xpath=//div[@id='ui-datepicker-div']/div/div/select[2]", "xpath:idRelative"],
        ["xpath=//select[2]", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "0e7ebb60-2011-45ed-a30a-6a3bfeaa334a",
      "comment": "",
      "command": "click",
      "target": "css=.ui-state-hover > font > font",
      "targets": [
        ["css=.ui-state-hover > font > font", "css:finder"],
        ["xpath=//div[@id='ui-datepicker-div']/table/tbody/tr[2]/td[4]/a/font/font", "xpath:idRelative"],
        ["xpath=//td[4]/a/font/font", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "0c252ce9-cd11-4018-88c2-ffc15c16b904",
      "comment": "",
      "command": "click",
      "target": "id=candidateSearch_fromDate",
      "targets": [
        ["id=candidateSearch_fromDate", "id"],
        ["name=candidateSearch[dateApplication][from]", "name"],
        ["css=#candidateSearch_fromDate", "css:finder"],
        ["xpath=//input[@id='candidateSearch_fromDate']", "xpath:attributes"],
        ["xpath=//form[@id='frmSrchCandidates']/fieldset/ol/li[7]/input", "xpath:idRelative"],
        ["xpath=//li[7]/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "3b902975-7a0c-423d-8c24-6c8138edc6fe",
      "comment": "",
      "command": "click",
      "target": "id=candidateSearch_fromDate",
      "targets": [
        ["id=candidateSearch_fromDate", "id"],
        ["name=candidateSearch[dateApplication][from]", "name"],
        ["css=#candidateSearch_fromDate", "css:finder"],
        ["xpath=//input[@id='candidateSearch_fromDate']", "xpath:attributes"],
        ["xpath=//form[@id='frmSrchCandidates']/fieldset/ol/li[7]/input", "xpath:idRelative"],
        ["xpath=//li[7]/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "1fed9498-808c-4654-99bc-a414d88ecd74",
      "comment": "",
      "command": "type",
      "target": "id=candidateSearch_fromDate",
      "targets": [
        ["id=candidateSearch_fromDate", "id"],
        ["name=candidateSearch[dateApplication][from]", "name"],
        ["css=#candidateSearch_fromDate", "css:finder"],
        ["xpath=//input[@id='candidateSearch_fromDate']", "xpath:attributes"],
        ["xpath=//form[@id='frmSrchCandidates']/fieldset/ol/li[7]/input", "xpath:idRelative"],
        ["xpath=//li[7]/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "bbadf6a4-10c2-4583-97b6-d4f5afaaebed",
      "comment": "",
      "command": "click",
      "target": "css=#frmSrchCandidates ol",
      "targets": [
        ["css=#frmSrchCandidates ol", "css:finder"],
        ["xpath=//form[@id='frmSrchCandidates']/fieldset/ol", "xpath:idRelative"],
        ["xpath=//div[3]/div/div[2]/form/fieldset/ol", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "cd065d97-ce4e-4dfc-add8-76c8d13e9c9f",
      "comment": "",
      "command": "click",
      "target": "id=candidateSearch_keywords",
      "targets": [
        ["id=candidateSearch_keywords", "id"],
        ["name=candidateSearch[keywords]", "name"],
        ["css=#candidateSearch_keywords", "css:finder"],
        ["xpath=//input[@id='candidateSearch_keywords']", "xpath:attributes"],
        ["xpath=//form[@id='frmSrchCandidates']/fieldset/ol/li[6]/input", "xpath:idRelative"],
        ["xpath=//li[6]/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "db4f9e7b-aecb-4da3-ab5a-3088b029287e",
      "comment": "",
      "command": "type",
      "target": "id=candidateSearch_keywords",
      "targets": [
        ["id=candidateSearch_keywords", "id"],
        ["name=candidateSearch[keywords]", "name"],
        ["css=#candidateSearch_keywords", "css:finder"],
        ["xpath=//input[@id='candidateSearch_keywords']", "xpath:attributes"],
        ["xpath=//form[@id='frmSrchCandidates']/fieldset/ol/li[6]/input", "xpath:idRelative"],
        ["xpath=//li[6]/input", "xpath:position"]
      ],
      "value": "опыт"
    }, {
      "id": "3ed95327-80aa-404e-b160-aafbb2294fce",
      "comment": "",
      "command": "click",
      "target": "id=candidateSearch_candidateName",
      "targets": [
        ["id=candidateSearch_candidateName", "id"],
        ["name=candidateSearch[candidateName]", "name"],
        ["css=#candidateSearch_candidateName", "css:finder"],
        ["xpath=//input[@id='candidateSearch_candidateName']", "xpath:attributes"],
        ["xpath=//form[@id='frmSrchCandidates']/fieldset/ol/li[5]/input", "xpath:idRelative"],
        ["xpath=//li[5]/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "1703d508-e4b0-4dbb-ad14-bf0d078aa8df",
      "comment": "",
      "command": "click",
      "target": "id=btnSrch",
      "targets": [
        ["id=btnSrch", "id"],
        ["name=btnSrch", "name"],
        ["css=#btnSrch", "css:finder"],
        ["xpath=//input[@id='btnSrch']", "xpath:attributes"],
        ["xpath=//form[@id='frmSrchCandidates']/fieldset/p/font/font/input", "xpath:idRelative"],
        ["xpath=//p/font/font/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "cbfd5ebe-ee6b-41ee-92db-f48bbf058190",
      "comment": "",
      "command": "click",
      "target": "id=candidateSearch_candidateName",
      "targets": [
        ["id=candidateSearch_candidateName", "id"],
        ["name=candidateSearch[candidateName]", "name"],
        ["css=#candidateSearch_candidateName", "css:finder"],
        ["xpath=//input[@id='candidateSearch_candidateName']", "xpath:attributes"],
        ["xpath=//form[@id='frmSrchCandidates']/fieldset/ol/li[5]/input", "xpath:idRelative"],
        ["xpath=//li[5]/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "3f9ecf0f-bb86-4afe-972c-1c2c220ae4c1",
      "comment": "",
      "command": "click",
      "target": "id=btnSrch",
      "targets": [
        ["id=btnSrch", "id"],
        ["name=btnSrch", "name"],
        ["css=#btnSrch", "css:finder"],
        ["xpath=//input[@id='btnSrch']", "xpath:attributes"],
        ["xpath=//form[@id='frmSrchCandidates']/fieldset/p/input", "xpath:idRelative"],
        ["xpath=//p/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "335c07de-ecf7-4a44-8812-fbc0a2d2201b",
      "comment": "",
      "command": "click",
      "target": "id=welcome",
      "targets": [
        ["id=welcome", "id"],
        ["linkText=Welcome Paul", "linkText"],
        ["css=#welcome", "css:finder"],
        ["xpath=//a[contains(text(),'Welcome Paul')]", "xpath:link"],
        ["xpath=//a[@id='welcome']", "xpath:attributes"],
        ["xpath=//div[@id='branding']/a[2]", "xpath:idRelative"],
        ["xpath=//a[contains(@href, '#')]", "xpath:href"],
        ["xpath=//a[2]", "xpath:position"],
        ["xpath=//a[contains(.,'Welcome Paul')]", "xpath:innerText"]
      ],
      "value": ""
    }, {
      "id": "e49981b9-acc8-47ff-85b9-c29b7d12e4cd",
      "comment": "",
      "command": "click",
      "target": "css=ul:nth-child(1) > li:nth-child(2) > a > font > font",
      "targets": [
        ["css=ul:nth-child(1) > li:nth-child(2) > a > font > font", "css:finder"],
        ["xpath=//div[@id='welcome-menu']/ul/li[2]/a/font/font", "xpath:idRelative"],
        ["xpath=//li[2]/a/font/font", "xpath:position"]
      ],
      "value": ""
    }]
  }, {
    "id": "7718ceb8-1a64-49c3-8b95-3c070483be20",
    "name": "05",
    "commands": [{
      "id": "00a819a0-e64b-4591-81a6-404d05befc5f",
      "comment": "",
      "command": "open",
      "target": "https://opensource-demo.orangehrmlive.com/",
      "targets": [],
      "value": ""
    }, {
      "id": "0a80d83a-2fd8-4f9c-932b-8ae4ebe53d5b",
      "comment": "",
      "command": "setWindowSize",
      "target": "857x1040",
      "targets": [],
      "value": ""
    }, {
      "id": "7c996f64-d922-44a1-a2d2-d1c515a06a6a",
      "comment": "",
      "command": "click",
      "target": "css=#divUsername > .form-hint",
      "targets": [
        ["css=#divUsername > .form-hint", "css:finder"],
        ["xpath=//div[@id='divUsername']/span", "xpath:idRelative"],
        ["xpath=//form/div[2]/span", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "ad8ae131-7a21-4672-a421-db16dbf396d4",
      "comment": "",
      "command": "type",
      "target": "id=txtUsername",
      "targets": [
        ["id=txtUsername", "id"],
        ["name=txtUsername", "name"],
        ["css=#txtUsername", "css:finder"],
        ["xpath=//input[@id='txtUsername']", "xpath:attributes"],
        ["xpath=//div[@id='divUsername']/input", "xpath:idRelative"],
        ["xpath=//div[2]/input", "xpath:position"]
      ],
      "value": "hddgjjfdjd"
    }, {
      "id": "51d5f223-7e42-4ce8-b00d-34fe02ec3b47",
      "comment": "",
      "command": "click",
      "target": "id=txtPassword",
      "targets": [
        ["id=txtPassword", "id"],
        ["name=txtPassword", "name"],
        ["css=#txtPassword", "css:finder"],
        ["xpath=//input[@id='txtPassword']", "xpath:attributes"],
        ["xpath=//div[@id='divPassword']/input", "xpath:idRelative"],
        ["xpath=//div[3]/input", "xpath:position"]
      ],
      "value": ""
    }, {
      "id": "dcea4ba7-9c5e-4c8b-b316-ccc512c32bb1",
      "comment": "",
      "command": "type",
      "target": "id=txtPassword",
      "targets": [
        ["id=txtPassword", "id"],
        ["name=txtPassword", "name"],
        ["css=#txtPassword", "css:finder"],
        ["xpath=//input[@id='txtPassword']", "xpath:attributes"],
        ["xpath=//div[@id='divPassword']/input", "xpath:idRelative"],
        ["xpath=//div[3]/input", "xpath:position"]
      ],
      "value": "admin123"
    }, {
      "id": "6ce6c175-13cd-42dd-8597-3b19f131d1f7",
      "comment": "",
      "command": "click",
      "target": "id=btnLogin",
      "targets": [
        ["id=btnLogin", "id"],
        ["name=Submit", "name"],
        ["css=#btnLogin", "css:finder"],
        ["xpath=//input[@id='btnLogin']", "xpath:attributes"],
        ["xpath=//div[@id='divLoginButton']/input", "xpath:idRelative"],
        ["xpath=//div[5]/input", "xpath:position"]
      ],
      "value": ""
    }]
  }],
  "suites": [{
    "id": "1ddd1331-a59b-4b26-9db3-47ebc9d5a173",
    "name": "Default Suite",
    "persistSession": false,
    "parallel": false,
    "timeout": 300,
    "tests": ["2b73609c-7020-4e9c-88f0-6184309deca0"]
  }],
  "urls": ["https://opensource-demo.orangehrmlive.com/"],
  "plugins": []
}